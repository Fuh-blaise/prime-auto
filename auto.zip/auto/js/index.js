function showNav() {
    var navbar = document.getElementById('main-nav');
    if(navbar.style.display === "block"){
        navbar.style.display = "none"
    }else{
        navbar.style.display = "block"

    }
}